# Moving from the v1 Web SDK to `@streampixel/web-sdk` (v2)

v1 is the `StreamPixelApplication` function of the `streampixelsdk` package, installed from the `Streampixel-Web-SDK` GitHub repository. v2 is `@streampixel/web-sdk`, described in the [README](./README.md).

v2 is a different API. No v1 page runs unchanged: plan to rewrite the file that starts the stream. A few v1 method names still work on the v2 object (section 11), so the rest of your code can move in steps.

Why move: v1 sends no ticket (the short-lived credential the platform issues for one streaming session). The platform is moving to require one for every session; a v1 page is then refused when it connects.

> **Public beta.** `@streampixel/web-sdk` and `@streampixel/ui` are on npm under the `next` tag (`npm install @streampixel/web-sdk@next`). Keep v1 in production until you have tested v2 with your own project.

## Contents

1. [Before you start: three things that change without any code](#1-before-you-start)
2. [Install](#2-install)
3. [Start a stream](#3-start-a-stream)
4. [Settings](#4-settings)
5. [Messages to and from your application](#5-messages-to-and-from-your-application)
6. [The screens v1 drew for you](#6-the-screens-v1-drew-for-you)
7. [Controls: sound, resolution, statistics, microphone](#7-controls)
8. [Password, single sign-on, your app only](#8-access)
9. [Shared sessions](#9-shared-sessions)
10. [Voice and text chat](#10-voice-and-text-chat)
11. [v1 names that still work](#11-v1-names-that-still-work)
12. [What has no equivalent](#12-what-has-no-equivalent)
13. [Behaviour that changed](#13-behaviour-that-changed)
14. [Check list](#14-check-list)

<a id="1-before-you-start"></a>

## 1. Before you start: three things that change without any code

### Access modes are now enforced

v1 ignored the project's access setting: it streamed a password-protected or single sign-on project with no prompt. v2 follows the setting.

| Project access in the dashboard | v1 page | v2 page |
|---|---|---|
| Public | streams | streams |
| Password | streams, no prompt | waits for the password (state `awaitingPassword`) |
| Single sign-on | streams, no prompt | sends the viewer to the sign-in page |
| Your app only | streams, no prompt | needs a ticket from your server |

Check each project's access setting before you move its page. If you put a password on a project only to protect its share link, and your site has its own sign-in, **Your app only** is the mode for you (section 8).

### The allowed-domains list is checked by the platform

v1 checked the project's allowed-domains list in the browser, loosely: an entry matched when the page address contained it, `*` wildcards worked, and `localhost` was always allowed. In v2 the platform checks the list when the page connects.

| | v1 | v2 |
|---|---|---|
| Where | in the browser | on the platform |
| Match | the page address contains the entry | **the exact origin** of the page: scheme, host and port |
| `example.com` listed, page on `https://www.example.com` | allowed | not the same origin today. Handling of `www.` is being fixed on the platform. |
| `example.com` listed, page on `https://app.example.com` | allowed | refused: list each origin you use |
| Wildcard entries such as `*.example.com` | allowed | do not rely on them: list each origin |
| `localhost` | always allowed | do not assume it is: test your local address |

A page on an origin that is not allowed is refused when it connects: the session ends with code `1008`. If your project has a list, test the page on its real domain before going live.

### Content-Security-Policy

v1 was one bundle. v2 downloads its engine from Streampixel's servers when `create()` runs, and talks to different hosts. If your site sends a Content-Security-Policy header:

```
script-src  https://js.streampixel.io https://js-backup.streampixel.io;
connect-src https://*.streampixel.io wss://*.streampixel.io;
```

Add `wss://*.livekit.cloud https://*.livekit.cloud` to `connect-src` if you use chat. v2 no longer calls `api.streampixel.io`, `logger.streampixel.io` or `mixapi.streampixel.io`. If the engine cannot be downloaded, `create()` rejects with `EngineLoadError`; there is no copy inside the package.

## 2. Install

```bash
# v1
npm install git+https://github.com/infinity-void-metaverse/Streampixel-Web-SDK.git#latest

# v2
npm uninstall streampixelsdk
npm install @streampixel/web-sdk@next @streampixel/ui@next
```

`@streampixel/ui` draws the screens v1 drew by itself (section 6). Without a bundler, the core is also available from a script tag (`https://js.streampixel.io/v2/loader.js`, global `StreamPixelSDK`); `@streampixel/ui` and chat are npm only.

## 3. Start a stream

```js
// v1
import { StreamPixelApplication } from 'streampixelsdk';

const { appStream, pixelStreaming, queueHandler, UIControl, reconnectStream } =
  await StreamPixelApplication({ appId: 'PROJECT_ID', AutoConnect: true });

appStream.onVideoInitialized = () => {
  document.getElementById('stream').append(appStream.rootElement);
};
```

```ts
// v2
import { StreamPixel, AuthError, EngineLoadError } from '@streampixel/web-sdk';
import { mountUI } from '@streampixel/ui';

const container = document.getElementById('stream')!; // give it a width and a height

try {
  const stream = await StreamPixel.create({ appId: 'PROJECT_ID', container });
  mountUI(stream, { container }); // loading, password, "Click to start", idle warning, text input, end message
} catch (err) {
  if (err instanceof AuthError) showMessage(`${err.kind}: ${err.message}`);          // 'project-offline', 'project-not-found', …
  else if (err instanceof EngineLoadError) showMessage('The player could not be loaded.');
  else throw err;
}
```

| v1 | v2 |
|---|---|
| Five returned objects | One object, `stream`. |
| Returned `null` or `{}` when it could not start | `create()` throws: `AuthError` (with a `kind`), `EngineLoadError`, or `TypeError` for a wrong option. |
| One stream per page (a second call returned `{}`) | Any number. Call `stream.destroy()` before starting another stream in the same container. |
| You appended `appStream.rootElement` | You pass `container`; the SDK puts the video in it. The container must be an element with a width; see "The container" in the README. |
| `AutoConnect: false`, then `pixelStreaming.connect()` | `create()` always starts the stream. Call `create()` when the viewer presses your button (below). |
| `pixelStreaming.reconnect()`, "click to restart" | `ended` is final. Call `stream.destroy()`, then `create()` again, and attach your listeners again. |

```ts
document.getElementById('play')!.onclick = async () => {
  const stream = await StreamPixel.create({ appId: 'PROJECT_ID', container });
  mountUI(stream, { container });
};
```

### React

v1 examples called `disconnect()` in the effect cleanup. In v2 pass a `signal` and abort it: without it, React StrictMode's double effect (or a fast unmount) leaves a session streaming in the background. The README has a full hook.

```tsx
import { useEffect, useRef } from 'react';
import { StreamPixel } from '@streampixel/web-sdk';
import { mountUI, type MountedUI } from '@streampixel/ui';

export function Stream({ appId }: { appId: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    if (!container) return;
    const ac = new AbortController();
    let ui: MountedUI | undefined;

    StreamPixel.create({ appId, container, signal: ac.signal })
      .then((stream) => { ui = mountUI(stream, { container }); })
      .catch((err) => { if (err.name !== 'AbortError') showError(String(err)); });

    return () => {
      ui?.destroy(); // the UI first
      ac.abort();    // before create() resolves: nothing starts. After: the stream is destroyed.
    };
  }, [appId]);

  return <div ref={ref} style={{ width: '100%', height: '100%' }} />;
}
```

## 4. Settings

| v1 | v2 |
|---|---|
| `appId` | `appId`. (`projectId` is accepted too, with a console warning.) |
| `AutoConnect` | Removed: `create()` always connects. |
| `streamerId` | `advanced: { streamerId }`. Letters, digits, `_` and `-` only. v2 connects as `<streamerId>_<projectId>`. |
| `sfuHost: 'true'` | `shared: { role: 'host' }` (section 9) |
| `sfuPlayer: 'true'` | `shared: { role: 'viewer', hostStreamerId }` (section 9) |
| `forceTurn: true` | `advanced: { iceTransportPolicy: 'relay' }`. v1 forced the relay unless you turned it off; v2 does not (section 13). |
| `primaryCodec`, `fallBackCodec` | `codec: { primary, fallback }`. `fallback` is `'H264'` or `'VP8'`. |
| `maxStreamQuality` | `resolution: { max }`. In v1 it only shortened the picker list; in v2 it is a real upper limit. |
| `startResolution`, `startResolutionMobile`, `startResolutionTab` | `resolution: { start, mobileStart, tabletStart }`. The `'360p (640x360)'` preset is written `{ width: 640, height: 360 }`. |
| `resolutionMode: 'Fixed Resolution Mode'` / `'Dynamic Resolution Mode'` / `'Crop on Resize Mode'` | `resolution: { mode: 'fixed' }` / `'dynamic'` / `'crop'` |
| `minBitrate`, `maxBitrate` | `bitrate: { min, max }` in **kilobits per second**: 20 Mbps is `20_000`. The v1 pages called these Mbps; give v2 the rate you actually want. |
| `minQP`, `maxQP` | No option. Set in the dashboard. |
| `mouseInput`, `keyBoardInput`, `touchInput`, `hoverMouse`, `gamepadInput`, `xrInput`, `fakeMouseWithTouches` | `input: { mouse, keyboard, touch, hover, gamepad, xr, fakeMouseWithTouches }` |
| `useMic`, `useCamera` | `media: { mic, camera }` |
| `afktimeout` | `afk: { timeoutSec }`. Only shorter than the dashboard's value (section 13). |
| `showResolution` | Removed. Build a picker with `stream.allowedResolutions` and `stream.setResolution()`. |

What you leave out comes from the project's dashboard settings. An option name v2 does not know is ignored with a console warning, so a v1 name left in place does not fail silently.

## 5. Messages to and from your application

```js
// v1
appStream.stream.emitUIInteraction({ type: 'setColor', value: 'red' });
pixelStreaming.emitConsoleCommand('stat fps');
pixelStreaming.addResponseEventListener('handle_responses', (response) => {
  const data = JSON.parse(response);
});
```

```ts
// v2
stream.send({ type: 'setColor', value: 'red' });        // returns false when it was not sent
stream.consoleCommand('stat fps');                      // returns false when it was not sent
stream.on('ueMessage', (response) => {
  const data = typeof response === 'string' && response.trim().startsWith('{') ? JSON.parse(response) : response;
  console.log(data);
});
```

`send()` and `consoleCommand()` return `false` when the message was not handed to the stream (before the video is up, while reconnecting, after the end). Nothing is queued.

## 6. The screens v1 drew for you

v1 drew its own connecting screen, queue text, idle countdown, text box for phones and "Disconnected" screen. **The v2 core draws only the video.** A page moved to the core alone has no idle warning, no end message, no "Click to start" when the browser blocks autoplay, and text fields in the application stop working on phones.

The simplest move is `mountUI(stream, { container })` from `@streampixel/ui`, which draws all of these:

| v1 screen | `@streampixel/ui` part (option name) |
|---|---|
| Connecting screen, queue text | `loading`: the project's logo, banner and loading texts, queue position, reconnecting status |
| (none: v1 ignored passwords) | `password` |
| Play overlay | `playPrompt`: "Click to start" when the browser blocks autoplay |
| Idle countdown | `afk` |
| Text box for phones | `osk` |
| "Disconnected code:N. Click To Restart" | `disconnect`: the end message in plain language and a button |
| Stats panel, settings | `controls`: sound, fullscreen, a statistics popup |
| (none) | `files`, `links`, `tcpToast`: files and links the application sends, and the warning when UDP is blocked |

CSS written for v1's elements (`#afkOverlay`, `#connectOverlay`, `#infoOverlay`, `#uiFeatures`) matches nothing in v2; `@streampixel/ui` uses `spx-*` class names. `appStream.showDisconnectOverlay()`, `appStream.showTextOverlay()` and `appStream.statsPanel` have no v2 call.

To draw a screen yourself, switch that part off and use the events:

```ts
mountUI(stream, { container, loading: false, disconnect: false });
```

### Loading, queue, reconnecting, ended

```js
// v1
pixelStreaming.addEventListener('webRtcConnecting', () => setStatus('Connecting…'));
pixelStreaming.addEventListener('webRtcConnected', () => setStatus('Loading…'));
appStream.onVideoInitialized = () => hideLoading();
queueHandler((msg) => setStatus(`In queue: ${msg.position}`));
reconnectStream.on('state', (d) => {
  if (d.status === 'reconnecting') setStatus('Reconnecting…');
  if (d.status === 'failed') setStatus('Could not reconnect');
});
```

```ts
// v2: one state event
stream.on('state', (s) => {
  switch (s.kind) {
    case 'awaitingPassword': break;                                     // your own password form, or mountUI's
    case 'connecting':   setStatus('Connecting…'); break;
    case 'queued':       setStatus(`In queue: ${s.position}`); break;
    case 'streaming':    hideLoading(); break;
    case 'awaitingPlay': showStartButton(() => stream.play()); break;   // the browser blocked autoplay
    case 'reconnecting': setStatus('Reconnecting…'); break;             // automatic, up to 180 s
    case 'recovering':   setStatus('Restarting the stream…'); break;
    case 'ended':        setStatus(s.message); break;                   // also s.code, s.reason, s.endKind
  }
});
stream.on('progress', ({ stage }) => setStep(stage));                   // 'offer', then 'answer', then 'connected'
```

| v1 | v2 |
|---|---|
| `webRtcConnecting`, `webRtcSdp`, `webRtcConnected`, `streamLoading` | state `connecting` (or `queued`); `progress` for the steps |
| `playStream`, `appStream.onVideoInitialized` | state `streaming` (or `awaitingPlay` when autoplay is blocked) |
| `webRtcDisconnected`, `webRtcFailed` | state `reconnecting` or `recovering` (automatic), or `ended` |
| `queueHandler(fn)` | `stream.on('queue', ({ position, message }) => …)`, or state `queued` |
| `reconnectStream` `reconnecting` / `retrying` | state `reconnecting` |
| `reconnectStream` `connected` | state `streaming` |
| `reconnectStream` `failed` (code 4007) | `ended` with `code === 4007` |
| `reconnectStream` `disconnected` | `ended` |
| `statsReceived` | `stats` |
| (none) | `ended` `{ code, reason, endKind, message }`, `session`, `stalled`, `autoplayBlocked`, `openUrl`, `file`, `fileProgress`, `screenshot`, `relayFallback` |

All listeners added with `stream.on()` are removed when the session ends. Do not keep a reference to the `<video>` element or to `stream.pixelStreaming`: v2 replaces both when it rebuilds the connection.

### Idle warning

```js
// v1
pixelStreaming.addEventListener('afkWarningActivate', (e) => showWarning(e.data.countDown, e.data.dismissAfk));
pixelStreaming.addEventListener('afkWarningUpdate', (e) => updateWarning(e.data.countDown));
pixelStreaming.addEventListener('afkWarningDeactivate', () => hideWarning());
pixelStreaming.addEventListener('afkTimedOut', () => showMessage('Session ended'));
```

```ts
// v2
stream.on('afkWarning', (w) => {
  if (w.kind === 'countdown') showIdleWarning(w.secondsRemaining, w.dismiss);
  else hideIdleWarning();
});
stream.on('ended', (e) => {
  if (e.endKind === 'afk') showMessage(e.message);
});
```

### Text input on phones

v1 opened a text box by itself when the application asked for the keyboard. In v2, `mountUI` does it, or you do:

```ts
stream.on('osk', ({ contents }) => openTextInput(contents, (text) => stream.sendTextboxEntry(text)));
stream.on('oskHide', () => closeTextInput());
```

<a id="7-controls"></a>

## 7. Controls: sound, resolution, statistics, microphone

```js
// v1
UIControl.toggleAudio();
UIControl.handleResMax('1920x1080');
UIControl.toggleHoveringMouse(true);
const options = UIControl.getResolution();
const stats = UIControl.getStreamStats();      // stats['Framerate'], stats['Net RTT (ms)'] …
```

```ts
// v2
const audible = stream.toggleAudio();            // true when the sound is now on; or stream.setMuted(true / false), stream.muted
const sentSize = stream.setResolution(1920, 1080); // { width, height } as sent, or null when nothing was sent
stream.setHoverMouse(true);
buildPicker(stream.allowedResolutions);          // ['360p (640x360)', …] up to the project's maximum
stream.on('stats', (s) => {                      // every second
  console.log(s.fps, s.latencyMs, s.bitrateKbps, s.resolution, s.codec,
    s.framesDecoded, s.framesDropped, s.packetsLost, s.bytesReceived, s.relayTransport, s.avgQp);
});
```

| v1 | v2 |
|---|---|
| `UIControl.toggleAudio()` | `stream.toggleAudio()`, `stream.setMuted(bool)`, `stream.muted` |
| `appStream.stream._webRtcController.streamController.audioElement`, `video.muted` | `stream.setMuted(bool)` |
| `UIControl.handleResMax('1920x1080')` | `stream.setResolution(1920, 1080)`. Never above the project's maximum. |
| `UIControl.toggleHoveringMouse(on)` | `stream.setHoverMouse(on)` |
| `UIControl.getResolution()` | `stream.allowedResolutions` (always the list; v1 returned nothing when the dashboard hid the picker) |
| `UIControl.getStreamStats()` | the `stats` event: `Framerate` → `fps`, `Net RTT (ms)` → `latencyMs`, `Video Bitrate (kbps)` → `bitrateKbps`, plus `resolution`, `codec`, `framesDecoded`, `framesDropped`, `packetsLost`, `bytesReceived`, `relayTransport`, `avgQp`. There is no v2 field for audio codec, audio bitrate or duration. |

### Microphone and camera to the application

```js
// v1
pixelStreaming.unmuteMicrophone(true);
pixelStreaming.unmuteCamera(true);
```

```ts
// v2
const withMic = await StreamPixel.create({ appId: 'PROJECT_ID', container, media: { mic: true } });
showMicButton(async () => {
  const live = await withMic.setMicrophone(true);   // false to switch it off again; setCamera(on) for the camera
  console.log('microphone live:', live);
});
```

The microphone or camera must be allowed when the stream starts (`media`, or the dashboard). With it allowed, the browser asks for permission once the video is up, and `setMicrophone(on)` / `setCamera(on)` switch it afterwards. Do not call `unmuteMicrophone()` or `unmuteCamera()` on `stream.pixelStreaming`: they make Epic's library reconnect on its own, against the SDK.

<a id="8-access"></a>

## 8. Password, single sign-on, your app only

v1 had none of these. In v2:

| Project access | What to do |
|---|---|
| Password | With `mountUI`, nothing: the password screen is drawn. With your own form: `create()` resolves in the state `awaitingPassword`; call `stream.submitPassword(typed)`. A wrong password comes back as `awaitingPassword` with `wrong: true`; too many attempts as `locked: true` (and `hard: true` when every attempt is refused for now). See "Password projects" in the README. |
| Single sign-on | Nothing: the SDK sends the viewer to the sign-in page and finishes when they come back. A refused sign-in rejects `create()` with `AuthError` kind `sso-failed`. |
| Your app only | Your server requests a ticket with the project's server key; your page passes the whole response as `auth: { mode: 'ticket', ticket }`. See "Your app only" in the README. |

Never put a project password in your page's code: anyone can read it there.

## 9. Shared sessions

A shared session runs one application for several people: a host who controls it and viewers who watch.

```js
// v1: host and viewers used the same streamerId
await StreamPixelApplication({ appId, AutoConnect: true, sfuHost: 'true', streamerId: 'room1' });
await StreamPixelApplication({ appId, AutoConnect: true, sfuPlayer: 'true', streamerId: 'room1' });
```

```ts
// v2
const host = await StreamPixel.create({ appId, container, shared: { role: 'host' } });
sendToViewers(host.streamerId);                  // the id viewers need
await StreamPixel.create({ appId, container, shared: { role: 'viewer', hostStreamerId } });
```

**`hostStreamerId` must be exactly the host's `stream.streamerId`.** In v2 that id is `<id>_<projectId>`, not the bare id. Porting `streamerId: 'room1'` to both sides gives a viewer that never joins. If both pages already agree on a room name, keep it like this:

```ts
// host
await StreamPixel.create({ appId, container, shared: { role: 'host' }, advanced: { streamerId: 'room1' } });
// viewer: the host's id is "<room>_<appId>"
await StreamPixel.create({ appId, container, shared: { role: 'viewer', hostStreamerId: `room1_${appId}` } });
```

| Topic | v2 |
|---|---|
| Room names | Letters, digits, `_` and `-` only. |
| One host per room | Whoever opens a room first is its host. A second host for the same room is refused: `create()` rejects with `AuthError` kind `shared-room-taken`. The host's own tab can come back to its room after a reload. |
| Host page reload | Without a room name of your own, the host returns to the same room after a reload of its tab. |
| Viewers | Cannot control the application and are not disconnected for being idle. |
| Host's application restarts | Viewers wait up to 10 minutes (state `reconnecting` with `waitingForHost: true`). |
| "Your app only" projects | The host's ticket must ask for the host role. See "Shared sessions" in the README. |

## 10. Voice and text chat

```js
// v1
import { StreamPixelVoiceChat } from 'streampixelsdk';
const chat = new StreamPixelVoiceChat('room-1', userName, true, avatar, true);
await chat.join();
chat.onMessage((m) => show(m.from, m.text));
chat.onParticipantUpdate((p) => list(p.remoteParticipants));
chat.toggleMic();
chat.muteSelected(id);
```

```ts
// v2
const chat = await VoiceChat.for(stream, { userName, avatar, voice: true, roomId: 'room-1' });
await chat.join();
chat.on('message', (m) => show(m.from, m.text));
chat.on('roster', (r) => list(r.remoteParticipants));
await chat.toggleMic(false);                     // pass the state you want
chat.setRemoteAudio(false, participantId);       // without an id: everyone
```

`VoiceChat` is imported from `@streampixel/web-sdk/voice`.

| v1 | v2 |
|---|---|
| `new StreamPixelVoiceChat(room, user, voiceChat, avatar, micStart)` | `await VoiceChat.for(stream, { userName, avatar, voice, roomId })` |
| Any room name | The room belongs to the project. `roomId` is a room inside it; without it everyone on the project shares one room. A v2 room is not the v1 room of the same name. |
| Worked on any project | Chat must be switched on for the project; otherwise `VoiceChat.for()` rejects. |
| `micStart` | `voice: true` |
| `toggleMic()` | `toggleMic(enable)`, resolves to whether it took effect; also `toggleCamera(enable)` |
| `onMessage(fn)`, `onParticipantUpdate(fn)` | `on('message', fn)`, `on('roster', fn)`; also `typing`, `deviceError`. Any number of listeners. |
| `muteAllRemote()`, `unmuteAllRemote()`, `muteSelected(id)`, `unmuteSelected(id)` | `setRemoteAudio(enabled, id?)` |

## 11. v1 names that still work

These are on the v2 `stream` object so that code can move in steps. Prefer the v2 names.

```ts
stream.emitUIInteraction({ type: 'setColor', value: 'red' });
stream.emitConsoleCommand('stat fps');
stream.addResponseEventListener('handle_responses', (response) => console.log(response));
stream.addEventListener('playStream', () => console.log('playing'));
```

| On `stream` | Note |
|---|---|
| `emitUIInteraction(data)`, `emitConsoleCommand(cmd)` | Same as `send()` and `consoleCommand()`. |
| `addResponseEventListener(name, fn)`, `removeResponseEventListener(name)` | Same messages as `on('ueMessage')`, as a string. |
| `addEventListener(epicEventName, fn)`, `removeEventListener(epicEventName, fn)` | Epic's events by their original names. Your listeners are attached again when the SDK rebuilds the connection. |
| `pixelStreaming` | Epic's `PixelStreaming` object. It is replaced when the connection is rebuilt: read it each time. |

Through `addEventListener`, `webRtcDisconnected` fires on every signalling drop, including the ones v2 recovers from by itself. A v1 handler that shows "Disconnected" on that event will show it during a reconnect that succeeds. Drive your screens from the `state` event.

## 12. What has no equivalent

| v1 | In v2 |
|---|---|
| Epic's classes exported by `streampixelsdk` (`Config`, `Flags`, `PixelStreaming`, `Application`, `AFKOverlay`, `SettingUI…`, `Logger`, …) | Not exported. `stream.pixelStreaming` is an instance, not the classes. |
| `appStream.showDisconnectOverlay()`, `appStream.showTextOverlay()`, `appStream.statsPanel`, `appStream.uiFeaturesElement` | No call. `@streampixel/ui` draws its own screens. |
| `pixelStreaming.connect()` with `AutoConnect: false`, `pixelStreaming.reconnect()` | No manual connect or reconnect. `create()` starts; `destroy()` then `create()` starts again. |
| `minQP`, `maxQP` options | Dashboard only. |
| The `stream-state` messages v1 posted to `window.parent` (`disconnected` with code 4007, `afkAbort`) | Nothing is posted. Post your own from the events (below). |
| Statistics for audio codec, audio bitrate and duration | Not in `StreamStats`. Epic's `statsReceived` event is still reachable with `stream.addEventListener('statsReceived', fn)`. |
| Mixpanel analytics | Removed. v2 reports to Streampixel's own telemetry only; no third-party tracker. |

```ts
stream.on('ended', ({ code, endKind }) => {
  window.parent.postMessage({ type: 'stream-state', value: 'disconnected', code, endKind }, 'https://your-site.example');
});
```

## 13. Behaviour that changed

| Topic | v1 | v2 |
|---|---|---|
| Relay | Every session was forced through the TURN relay unless you set `forceTurn: false`. | Direct when the network allows it. Set `advanced: { iceTransportPolicy: 'relay' }`, or the project's "force TURN" setting, if you depend on relay-only (for example firewall rules written for the relay). |
| Reconnecting | 60 seconds, one retry every 5 seconds, signalling only. | 180 seconds, retries after about 1, 2, 4, 8 and then 15 seconds. The whole connection is rebuilt when needed. Viewers of a shared session wait 10 minutes. |
| No video | Not detected. | After 10 seconds without a frame the SDK starts one fresh session: a new application process, so its state is lost and `launchParams` are sent again. |
| Blocked network | Not detected. | The session ends after about 8 seconds with `endKind: 'network-blocked'` (code `4100`). |
| End codes | The server's close code, and `4007` when reconnecting failed. | The same, plus codes the SDK decides in the browser: `4100` to `4104`. See "How a session ends" in the README. |
| Idle time | The page's `afktimeout` was used as given. | Never longer than the dashboard's value; 600 seconds when neither is set; cannot be switched off. Raise it in the dashboard if you used a long value in code. |
| Resolution | `handleResMax` sent any size. | Never above the project's maximum stream quality. |
| The first click | Spent on activating the application's window. | Reaches the application. |
| Keyboard | Every key went to the application. | Keys typed into your page's own inputs are not sent to the application. |

### New in v2: test your page against your own Unreal Editor

v1 had no way to run your page against an application that was not uploaded. v2 has the `dev` option: start a session in the dashboard's **Test Locally** tab, connect Unreal to it, and pass the session id to `create()`.

```ts
const stream = await StreamPixel.create({ appId: 'PROJECT_ID', container, dev: { sessionId: 'dev-1a2b3c' } });
```

The steps in the dashboard and in Unreal, and what is different in such a session, are in the README under "Test locally".

## 14. Check list

- [ ] Access mode of each project checked in the dashboard (section 1)
- [ ] Allowed-domains list checked against the exact origins of your pages, and tested (section 1)
- [ ] Content-Security-Policy updated, if you have one
- [ ] `streampixelsdk` removed; `@streampixel/web-sdk` (and `@streampixel/ui`) installed
- [ ] `StreamPixelApplication(...)` replaced by `StreamPixel.create(...)` with a `container` that has a size
- [ ] `mountUI` added, or your own screens for: loading, queue, password, "Click to start", idle warning, text input, end message
- [ ] Messages moved to `stream.send()` and `stream.on('ueMessage')`
- [ ] Cleanup: `signal` in React effects; `destroy()` before a new `create()`
- [ ] Shared sessions: viewers receive the host's `stream.streamerId`
- [ ] Relay: `advanced.iceTransportPolicy: 'relay'` if you depended on relay-only
- [ ] Tested on a phone (text input, autoplay, a link or file from the application) and through a short network drop
