# @streampixel/web-sdk

The Streampixel Web SDK v2 puts the stream of a Streampixel project (your Unreal Engine application, run on Streampixel's GPU servers) inside your own web page. It gives your code one `stream` object with typed states, events and errors. It draws nothing except the video.

This README describes version 2.0.0-alpha.11. Moving from the v1 SDK (`StreamPixelApplication`): see [MIGRATION.md](./MIGRATION.md).

> **Pre-release.** `@streampixel/web-sdk` is not on npm yet. Until it is, build the tarball (`npm pack` in `packages/core`) and install it with `npm install ./streampixel-web-sdk-<version>.tgz`. Names and behaviour can still change before 2.0.0.

## Contents

1. [Install](#install)
2. [Quick start](#quick-start)
3. [Loader and engine](#loader-and-engine)
4. [The container](#the-container)
5. [Options](#options)
6. [Access: public, password, single sign-on, your app only](#access)
7. [Errors from `create()`](#errors-from-create)
8. [States](#states)
9. [Reconnecting and recovery](#reconnecting-and-recovery)
10. [Events](#events)
11. [Methods and properties](#methods-and-properties)
12. [How a session ends, and end codes](#how-a-session-ends)
13. [Shared sessions](#shared-sessions)
14. [Voice, text and video chat](#voice-text-and-video-chat)
15. [React](#react)
16. [Telemetry and privacy](#telemetry-and-privacy)
17. [What is not in this package](#what-is-not-in-this-package)
18. [Browser requirements](#browser-requirements)

## Install

```bash
npm install @streampixel/web-sdk
```

The package has ESM and CommonJS builds with TypeScript types, and no runtime dependencies. Importing it touches no browser globals, so it can be imported during server-side rendering; only `StreamPixel.create()` needs a browser.

Without a bundler, load the same API from a script tag. It defines `window.StreamPixelSDK` with `StreamPixel`, `AuthError`, `EngineLoadError`, `DisconnectCodes` and `SDK_VERSION`:

```html
<script src="https://js.streampixel.io/v2/loader.js"></script>
<script>
  const { StreamPixel } = StreamPixelSDK;
</script>
```

## Quick start

You need the project id from the Streampixel dashboard (the option is called `appId`) and an element to put the video in.

```ts
import { StreamPixel, AuthError, EngineLoadError } from '@streampixel/web-sdk';

const container = document.getElementById('stream')!; // an element with a width: see "The container"
const status = document.getElementById('status')!;

try {
  const stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });

  stream.on('state', (s) => {
    status.textContent = s.kind === 'queued' ? `In queue: ${s.position}` : s.kind;
  });
  stream.on('ended', ({ code, endKind, message }) => {
    status.textContent = message;         // a sentence for the viewer
    console.log('ended', code, endKind);  // for your logs
  });
} catch (err) {
  if (err instanceof AuthError) status.textContent = `${err.kind}: ${err.message}`;
  else if (err instanceof EngineLoadError) status.textContent = `The player could not be loaded (${err.reason}).`;
  else throw err;
}
```

`create()` does four things:

1. Downloads and verifies the engine (see the next section).
2. Looks the project up on the Streampixel platform (is it online, how do viewers get in).
3. Asks the platform for a **ticket**: a short-lived credential for one streaming session. Passwords and single sign-on are checked here.
4. Resolves with the `stream` object. Connecting starts one moment later, so listeners you attach right after `await` see every state and event.

A viewer needs more than the video: a loading screen, a password form, a "Click to start" button when the browser blocks autoplay, an idle warning, a text field for phones, an end message. Either draw them from the states and events below, or mount [`@streampixel/ui`](../ui), which draws all of them:

```ts
import { StreamPixel } from '@streampixel/web-sdk';
import { mountUI } from '@streampixel/ui';

const container = document.getElementById('stream')!;
const stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });
const ui = mountUI(stream, { container });

// later, in this order
ui.destroy();
stream.destroy();
```

## Loader and engine

The package you install is a small **loader** with a fixed v2 API. The **engine**, the code that runs the stream (access, signalling, WebRTC, input, reconnection, telemetry), is not in the package. `create()` downloads it from Streampixel's servers, so fixes reach your site without a new install or deploy.

| Step | What the loader does |
|---|---|
| Find the engine | Fetches a list of engine builds (the manifest) from `https://js.streampixel.io`, or from the mirror `https://js-backup.streampixel.io`. Both hosts are fixed in the package: no option or URL parameter changes them. Each host gets 3 seconds; both are tried twice. |
| Trust it | The manifest is signed. The loader checks the signature with public keys built into the package, and refuses a manifest that has expired or is older than one this browser has already seen. |
| Load it | The engine file is loaded as a script with Subresource Integrity (the hash comes from the signed manifest), from the host that served the manifest, then from the other one. Each attempt gets 8 seconds. |

**When neither host can deliver a verified engine, `create()` rejects with `EngineLoadError`.** There is no copy of the engine in the package to fall back to, and no stream starts. `err.reason` says why (table in [Errors from `create()`](#errors-from-create)). A failed load is not remembered: calling `create()` again tries again.

The engine that runs can be newer or older than the package you installed. `stream.engineVersion` is the engine's version; `SDK_VERSION` is the package's. What this README describes is the behaviour of engine 2.0.0-alpha.11: a page that runs an older engine (check `stream.engineVersion`) does not have all of it.

```ts
await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container, engine: { channel: 'beta' } });        // the next release, for testing
await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container, engine: { version: '2.0.0-alpha.11' } }); // one exact build, no automatic updates

// Optional warm-up: downloads and verifies the engine without starting a session.
const { source, version } = await StreamPixel.preload();
console.log(source, version); // 'cdn' and the engine version, for example '2.0.0-alpha.11'
```

`source` (and `stream.engineSource`) is always `'cdn'` in the published package.

### Content-Security-Policy

If your site sends a Content-Security-Policy header, it must allow these hosts:

```
script-src  https://js.streampixel.io https://js-backup.streampixel.io;
connect-src https://*.streampixel.io wss://*.streampixel.io;
```

| Directive | Host | Used for |
|---|---|---|
| `script-src` | `js.streampixel.io`, `js-backup.streampixel.io` | the engine script |
| `connect-src` | `js.streampixel.io`, `js-backup.streampixel.io` | the signed manifest |
| `connect-src` | `platform.streampixel.io` | project lookup and the ticket |
| `connect-src` | `telemetry.streampixel.io` | telemetry |
| `connect-src` | a `wss://` host named in the ticket | signalling: the WebSocket on which the browser and your application agree on the video connection |

- Voice chat also needs `wss://*.livekit.cloud https://*.livekit.cloud` in `connect-src`.
- If you enforce Trusted Types (`require-trusted-types-for 'script'`), allow the policy name `streampixel-sdk`. The policy only accepts URLs on the two engine hosts.
- If you set `advanced.platformHost` or `advanced.telemetryHost`, allow those hosts instead.
- The page must be served over `https` (or from `localhost`): the loader needs WebCrypto to check the signature.

## The container

`container` must be an element (not a selector string). The SDK appends one element of its own to it and puts the `<video>` inside. Nothing else is added.

| Rule | Detail |
|---|---|
| Width | The container needs a width. The SDK's element is `width: 100%`. |
| Height | Give the container a height and the video fills it. If the container has a width and no height when the stream starts, the SDK's element takes the stream's aspect ratio instead, so the video is never zero pixels tall. |
| CSS `position` | Any. The video fills the container whether it is `static`, `relative` or anything else. |
| Overflow | The SDK's element is `overflow: hidden`. |
| No container | Omit `container` to start without a video on the page, and call `stream.attach(element)` later. That element needs a height of its own. |
| Element references | Do not keep a reference to the `<video>`: the SDK replaces it when it rebuilds the connection. |

How the video is fitted depends on the resolution mode (the project's dashboard setting, or `resolution.mode`):

| Mode | Stream size | In the container |
|---|---|---|
| `fixed` | The start resolution, or the size last set with `setResolution()`. | Whole picture visible, letterboxed (`object-fit: contain`). |
| `dynamic` | The container's size in device pixels (CSS size × `devicePixelRatio`), never above the start resolution (or the size set with `setResolution()`). Follows the container when it or the window is resized. | Fills the container. |
| `crop` | Same sizing as `dynamic`. | Fills the container edge to edge; what does not fit is cropped (`object-fit: cover`). |

For `dynamic` and `crop`, give the container both a width and a height: a container with no size yet is measured as the browser window.

`@streampixel/ui` puts its screens in the same container and sets `position: relative` on it when it is `static`.

## Options

Only `appId` is needed. Everything else defaults to the project's settings in the dashboard.

| Option | Type | Default | Meaning |
|---|---|---|---|
| `appId` | `string` | | The project id. May be omitted only on a page served from the project's verified custom domain (the project is then found by the page's hostname). |
| `container` | `HTMLElement` | | Where the video goes. See [The container](#the-container). |
| `auth` | see [Access](#access) | `{ mode: 'auto' }` | How the viewer gets in. |
| `rememberPassword` | `boolean` | `true` | Password projects: keep a correct password for this browser tab so a reload does not ask again. |
| `shared` | `{ role: 'host' }` or `{ role: 'viewer', hostStreamerId }` | | [Shared session](#shared-sessions). Omit for a private session. |
| `codec.primary` | `'AV1' \| 'H264' \| 'VP9' \| 'VP8'` | dashboard | Preferred video codec. The SDK orders the codecs the browser can decode, so a browser without the primary uses the fallback, then its own default. AV1 is used only when the application was built with Unreal Engine above 5.3. |
| `codec.fallback` | `'H264' \| 'VP8'` | dashboard | Used when the primary is not available. |
| `resolution.start` | `Resolution` | dashboard, else 1080p | Starting size. |
| `resolution.mobileStart`, `resolution.tabletStart` | `Resolution` | dashboard | Starting size on phones and on tablets (else `resolution.start`). |
| `resolution.max` | `Resolution` | dashboard | Ceiling for `setResolution()`. |
| `resolution.mode` | `'fixed' \| 'dynamic' \| 'crop'` | dashboard | See [The container](#the-container). |
| `bitrate.min`, `bitrate.max` | `number` | | Encoder limits in **kilobits per second**: `{ min: 1_000, max: 20_000 }` is 1 to 20 Mbps. A value above 200,000 logs a warning (it looks like bits per second). |
| `input.mouse`, `input.keyboard`, `input.touch` | `boolean` | dashboard (on) | Input sent to the application. |
| `input.hover`, `input.gamepad`, `input.xr`, `input.fakeMouseWithTouches` | `boolean` | dashboard (off) | Hover mouse (movement without a pressed button), gamepad, WebXR controllers, touches sent as mouse events. |
| `media.mic`, `media.camera` | `boolean` | dashboard | Send the viewer's microphone or camera to the application. The browser asks for permission after the video is up; an ignored prompt never delays the video. |
| `launchParams` | `object` | | Sent to the application once per started application, as one UI interaction, shortly after the first frame. Example: `{ unit: 'A-12', lang: 'fr' }`. |
| `afk.timeoutSec` | `number` | dashboard, else 600 | Seconds without input before the idle countdown. |
| `telemetry` | `'standard' \| 'minimal'` | `'standard'` | See [Telemetry and privacy](#telemetry-and-privacy). |
| `signal` | `AbortSignal` | | Aborting it cancels `create()` (it rejects with `AbortError` and nothing starts) or, once the stream exists, destroys it. See [React](#react). |
| `engine.channel` | `'stable' \| 'beta'` | `'stable'` | Which engine release runs. |
| `engine.version` | `string` | | Pin one exact engine version. |
| `advanced.iceTransportPolicy` | `'all' \| 'relay'` | | `'relay'` forces the stream through the TURN relay (a server that forwards the video when a direct path is not allowed). Unset, the project's "force TURN" setting decides. |
| `advanced.streamerId` | `string` | generated | Use your own id for this connection (letters, digits, `_` and `-`). |
| `advanced.platformHost`, `advanced.telemetryHost` | `string` | `https://platform.streampixel.io`, `https://telemetry.streampixel.io` | For dedicated and on-premises deployments. Must be `https` (`http` only on `localhost`). |
| `advanced.ticketInUrl` | `boolean` | `true` | `false` sends the ticket as the first signalling message instead of in the signalling URL. For deployments that require it. |
| `advanced.flags` | `object` | | Switches read by the engine. Unknown names are ignored. |

`Resolution` is `'480p (854x480)'`, `'720p (1280x720)'`, `'1080p (1920x1080)'`, `'1440p (2560x1440)'`, `'4K (3840x2160)'` or `{ width, height }` (two numbers of at least 64; odd values are rounded down to even ones).

Flags the engine reads (all on by default; `false` turns one off):

| Flag | Turns off |
|---|---|
| `isTouchDevice` | The `{ type: 'isTouchDevice', value, os, device }` message sent to the application on every video start. |
| `startupCommands` | Running the project's startup console commands. |
| `backgroundDisconnect` | Ending the session after 60 seconds in the background on phones and tablets. |
| `autoEnterVR` | Entering VR automatically in a headset browser. |

### What `create()` checks first

Option mistakes are reported before any network call:

| Mistake | Result |
|---|---|
| No options object; `appId` that is not a project id; `container` that is not an element; `shared.role` other than `'host'` / `'viewer'`; a viewer without a valid `hostStreamerId`; an `advanced.streamerId` with other characters than letters, digits, `_` and `-`; unknown codec; `auth.mode` other than `'auto'`, `'password'`, `'sso'`, `'ticket'`; `auth.mode: 'password'` without a password string; a host that is not `https`; `engine.version` that is not a version | `create()` rejects with `TypeError`. The message names the option. |
| `projectId` instead of `appId` | Accepted as `appId`, with a console warning. |
| An option name the SDK does not know | Ignored, with a console warning. |
| `loading` (removed) | Ignored, with a console warning: use `@streampixel/ui`. |

### Dashboard limits

For the settings that cost GPU time or bandwidth, the dashboard is the upper limit. Your code can ask for less, never more. A value above the limit is lowered to it, with one console warning.

| Setting | Your code can |
|---|---|
| Codec, resolution mode, input, microphone and camera | change it |
| `resolution.start`, `mobileStart`, `tabletStart`, `max`, `setResolution()` | go lower than the project's maximum stream quality, not higher. A project without a maximum is limited to 4K. |
| `afk.timeoutSec` | make the idle time shorter, not longer. Idle detection cannot be switched off: an idle session holds a GPU. |
| `bitrate` | set it. The platform does not send a project maximum today; when it does, the same rule applies. |

<a id="access"></a>

## Access: public, password, single sign-on, your app only

A project's access mode is set in the dashboard. With the default `auth: { mode: 'auto' }` the SDK follows it:

| Project access | What `create()` does with `auth: { mode: 'auto' }` |
|---|---|
| Public | Starts. |
| Password | Resolves with the stream in the state `awaitingPassword`. Nothing has started. See below. |
| Single sign-on (SSO) | Sends the browser to the sign-in page. When the viewer comes back to your page, call `create()` again: it finishes the sign-in from the URL. |
| Your app only | Rejects with `AuthError` kind `server-ticket-required`. Use `auth: { mode: 'ticket' }`. |

The other `auth` values:

| `auth` | Use |
|---|---|
| `{ mode: 'password', password }` | You already asked the viewer for the password in your own form. A wrong one lands in `awaitingPassword` with `wrong: true`, like `'auto'`. Never write a password in your code: page code is public. |
| `{ mode: 'sso' }` | Same as `'auto'` on an SSO project. |
| `{ mode: 'sso', redirect: 'manual' }` | The SDK does not navigate. `create()` rejects with kind `sso-required` and `ssoStartUrl`; your code navigates there. |
| `{ mode: 'ticket', ticket }` | "Your app only": your server requested the ticket. See below. |

### Password projects

`create()` resolves with `stream.state.kind === 'awaitingPassword'`. No ticket has been requested and no GPU is in use. Ask the viewer and call `submitPassword()`:

```ts
const stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });

const render = (s: StreamState) => {
  if (s.kind !== 'awaitingPassword') return hidePasswordForm();
  showPasswordForm({
    wrong: s.wrong === true,         // the last password was refused
    locked: s.locked === true,       // too many wrong attempts; the right password is still accepted
    disabled: s.hard === true,       // every attempt is refused for now: wait
    retryAfterSec: s.retryAfterSec,  // how long, when the server said
  });
};
stream.on('state', render);
render(stream.state); // create() resolves already in 'awaitingPassword' on a password project

form.onsubmit = (e) => {
  e.preventDefault();
  // Resolves for a right AND for a wrong password: the state says which.
  // Rejects with AuthError for a network error or a project that went offline.
  stream.submitPassword(input.value).catch((err: Error) => showError(err.message));
};
```

| After `submitPassword()` | State |
|---|---|
| Right password | The stream starts: `connecting`, then as usual. |
| Wrong password | `awaitingPassword` with `wrong: true`. |
| Too many wrong attempts (soft lockout) | `awaitingPassword` with `locked: true`, and `retryAfterSec` when the server said how long. The right password is still accepted: keep the field usable. |
| Every attempt refused for now (hard lockout) | `awaitingPassword` with `locked: true` and `hard: true`. Disable the form for `retryAfterSec` seconds. |
| Network error, project offline | `submitPassword()` rejects with `AuthError`; the state stays `awaitingPassword`. |
| Called in any other state, or while a check is running | Rejects with `Error`. |

The password is sent once, in the ticket request. It is never logged and never sent in telemetry. After a correct password the SDK keeps it for this browser tab only (`sessionStorage`) and tries it silently on the next `create()`, so a reload does not ask again. If it no longer works, the viewer is asked again without `wrong`. `rememberPassword: false` turns this off.

`@streampixel/ui` draws this screen for you.

### Single sign-on

With `'auto'` or `{ mode: 'sso' }` there is nothing to write: the SDK navigates to the sign-in page, and the next `create()` on your page reads the single-use grant from the URL (`?ssoGrant=`) and removes it from the address bar. `create()` still rejects with kind `sso-required` just before the page navigates away; ignore that one.

A sign-in that was refused, or a grant that was already used or has expired, rejects with kind `sso-failed`. `message` is a sentence for the viewer, `ssoErrorCode` is the sign-in service's code for your logs, and `ssoStartUrl` starts the sign-in again. To navigate yourself:

```ts
try {
  await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container, auth: { mode: 'sso', redirect: 'manual' } });
} catch (err) {
  if (!(err instanceof AuthError)) throw err;
  const signInUrl = err.ssoStartUrl;
  if ((err.kind === 'sso-required' || err.kind === 'sso-failed') && signInUrl) {
    if (err.kind === 'sso-failed') showMessage(err.message); // a sentence for the viewer; err.ssoErrorCode is for logs
    showSignInButton(() => window.location.assign(signInUrl));
  } else {
    showError(err.message);
  }
}
```

### Your app only

Use this when your own application already signs its users in. The project is set to **Your app only** in the dashboard and has a **server key**. Your server asks the Streampixel platform for a ticket for each signed-in user, and your page hands the answer to the SDK. The share page (Streampixel's own hosted page for a project, the one behind its share link) and plain iframes cannot start such a project.

```ts
// YOUR SERVER (Node 18+). Call it only after your own sign-in check.
export async function requestStreamTicket(projectId: string, viewerId: string): Promise<unknown> {
  const res = await fetch('https://platform.streampixel.io/api/v1/stream/ticket', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-server-key': process.env.STREAMPIXEL_SERVER_KEY ?? '', // never in a page
    },
    body: JSON.stringify({ projectId, viewerId }), // viewerId: your own id for this user
  });
  if (!res.ok) throw new Error(`Streampixel ticket request failed: ${res.status}`);
  return res.json(); // send this WHOLE object to your page, unchanged
}
```

```ts
// YOUR PAGE: '/api/stream-ticket' is your own endpoint, which returns what requestStreamTicket() returned.
const ticket = await (await fetch('/api/stream-ticket', { method: 'POST' })).json();

const stream = await StreamPixel.create({
  appId: 'YOUR_PROJECT_ID',
  container,
  auth: { mode: 'ticket', ticket }, // the whole response object (or its JSON text)
});
```

| Rule | Detail |
|---|---|
| Pass the whole response | `ticket` must be the response of `POST /api/v1/stream/ticket` as your server received it: the object, or its JSON text. It carries the ticket, the stream settings and the telemetry and chat tokens. **The ticket string alone is refused** (`AuthError` kind `server`): it carries no stream settings. |
| `appId` is still needed | The SDK looks the project up before it uses your ticket. |
| One ticket per `create()` | Request a new one for every `create()`, a page reload included. The SDK cannot renew your ticket. |
| The server key stays on your server | Anyone can read what is in a page. The platform refuses a server key sent from a browser. |
| No ticket | Opening a "your app only" project without one rejects with `AuthError` kind `server-ticket-required`. |
| Telemetry | Sent only when the response you pass still contains `telemetryToken`. |
| Shared sessions | The host's ticket must ask for the host role. See [Shared sessions](#shared-sessions). |

## Errors from `create()`

| Thrown | When |
|---|---|
| `AuthError` | The platform refused, could not be reached, or answered something unusable. `kind` says which. |
| `EngineLoadError` | The engine could not be loaded. `reason` says why. |
| `TypeError` | An option is wrong. The message names it. |
| `DOMException` named `AbortError` | You aborted `signal`. Nothing started. |

Each call to the platform has a limit of 10 seconds, retries included. Network errors and `502` / `503` / `504` answers are retried (up to three attempts); any other answer is final. Aborting `signal` during a platform call rejects at once; during the engine download, as soon as the download has finished or failed.

```ts
try {
  await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });
} catch (err) {
  if (err instanceof AuthError) {
    switch (err.kind) {
      case 'project-offline':   showMessage('This stream is unavailable right now.'); break;
      case 'project-not-found': showMessage('This stream does not exist.'); break;
      case 'rate-limited':      showMessage(`Too many attempts. Try again in ${err.retryAfterSec ?? 60} seconds.`); break;
      case 'sso-required':      break; // the page is already navigating to the sign-in page
      case 'sso-failed':        showMessage(err.message); break; // err.ssoStartUrl starts the sign-in again
      case 'network':           showMessage('Could not reach Streampixel. Check your connection.'); break;
      default:                  showError(`${err.kind}: ${err.message}`); // err.status: the HTTP status, when there was one
    }
  } else if (err instanceof EngineLoadError) {
    showError(`The player could not be loaded (${err.reason}).`);
  } else if ((err as Error).name === 'AbortError') {
    // you aborted `signal`: nothing started
  } else {
    throw err; // TypeError: an option is wrong (the message names it)
  }
}
```

### `AuthError`

| `kind` | Meaning | Extra fields |
|---|---|---|
| `project-not-found` | No project with this id, or none bound to this page's domain. | |
| `project-offline` | The project is switched off, or has no active build. Checked first: a viewer is never asked for a password or sent to sign in for a project that cannot stream. | |
| `sso-required` | The viewer must sign in. Thrown just before the SDK navigates, or instead of navigating with `redirect: 'manual'`. | `ssoStartUrl` |
| `sso-failed` | The sign-in was refused, or its grant was already used or has expired. `message` is one of a fixed set of sentences for the viewer. | `ssoStartUrl`, `ssoErrorCode` |
| `server-ticket-required` | A "your app only" project was opened without `auth: { mode: 'ticket' }`. | |
| `shared-room-taken` | Shared sessions: this room id already has a host. | |
| `rate-limited` | Too many requests from this network. | `retryAfterSec`, `hard` (`true`: every attempt is refused for now) |
| `network` | The platform could not be reached or did not answer within 10 seconds. Also thrown outside a browser with WebRTC. | |
| `server` | The platform's answer was not JSON, had no ticket or no stream settings, or was another refusal; also a bad `auth.ticket`. See `message` and `status`. | |
| `programmatic-only` | The platform refused the ticket request with a message naming programmatic access. | |
| `password-required`, `password-wrong` | Not thrown for `auth` `'auto'` or `'password'`: those resolve in `awaitingPassword`. | |

`kind` can be a value this list does not have yet: a newer engine may add one. Every `AuthError` has `message`, `kind` and, when the platform answered, `status` (the HTTP status). Once the project is known, the error also carries `branding` (logo, banner, loading texts, theme), so your own offline or sign-in screen can look like the project.

### `EngineLoadError`

| `reason` | Usual cause |
|---|---|
| `manifest-unavailable` | Neither host answered: offline, a firewall, an ad blocker, or a `connect-src` that does not allow them. |
| `engine-blocked` | The engine script was blocked: the network, your page's `script-src`, or a failed integrity check. |
| `engine-timeout` | The engine script did not load within 8 seconds. |
| `trusted-types` | Your Trusted Types policy refused the engine URL. Allow the policy `streampixel-sdk`. |
| `no-webcrypto` | The page is not served over `https` or from `localhost`. |
| `no-build` | The pinned `engine.version` does not exist. |
| `no-channel` | The manifest has no build for this `engine.channel`. |
| `needs-newer-loader` | The chosen engine needs a newer `@streampixel/web-sdk`: update the package. |
| `engine-register` | The engine script loaded and did not register itself. |
| `signature`, `manifest-expired`, `manifest-replayed`, `manifest-malformed`, `manifest-api` | The manifest failed a check and was refused. |
| `error` | Anything else; see `message`. |

## States

`stream.state` holds the current state and the `state` event fires on every change. Switch on `kind`:

```
awaitingPassword → connecting                 submitPassword() with the right password
connecting → (queued → connecting) → streaming
streaming → awaitingPlay → streaming          the browser blocked autoplay; a press calls play()
streaming → reconnecting → streaming          the connection dropped (through connecting when the connection is rebuilt)
connecting or streaming → recovering → connecting → streaming    no video: one fresh session
any → ended                                   final
```

| `kind` | Fields | Meaning |
|---|---|---|
| `idle` | | `create()` has resolved; connecting starts in a moment. |
| `awaitingPassword` | `wrong?`, `locked?`, `hard?`, `retryAfterSec?` | A password project waiting for `submitPassword()`. Nothing has started. |
| `connecting` | | Opening signalling, waiting for the application to start, and setting up the video connection. The `progress` event tells the steps apart. Also while a connection is rebuilt after a drop, and while a fresh session starts. |
| `queued` | `position` | Waiting for a free GPU. `position` is a whole number, `0` when the server did not say. The state goes back to `connecting` when the application answers. |
| `streaming` | | The video is playing. |
| `awaitingPlay` | `reason` | The stream is up and the browser refused to start playback without a user gesture. Show a "Click to start" control that calls `stream.play()`. A press anywhere on the container also starts it. |
| `recovering` | `attempt` | No video arrived (the `stalled` event says why). A fresh session is being started, or a shared-session viewer is rejoining its room. |
| `reconnecting` | `attempt`, `deadlineMs`, `waitingForHost?` | The connection dropped and the SDK is restoring it. `deadlineMs` is the time (epoch milliseconds) at which it gives up. `waitingForHost: true`: a shared-session viewer waiting for the host's application. |
| `ended` | `code`, `reason`, `endKind`, `message` | Final. See [How a session ends](#how-a-session-ends). |

The type also declares `resolving`, `starting` and `stalled`, marked deprecated. They are never emitted; they are in the type so that a `switch` written against an earlier 2.0 alpha still compiles. (`stalled` is an event; the state it leads to is `recovering`.) A newer engine may add a kind: keep a `default` branch.

```ts
export function statusText(s: StreamState): string {
  switch (s.kind) {
    case 'idle':
    case 'connecting':       return 'Connecting…';
    case 'awaitingPassword': return 'Enter the password';
    case 'queued':           return `In queue: ${s.position}`;
    case 'streaming':        return '';
    case 'awaitingPlay':     return 'Click to start';
    case 'recovering':       return 'Restarting the stream…';
    case 'reconnecting':     return s.waitingForHost ? 'Waiting for the host…' : 'Reconnecting…';
    case 'ended':            return s.message;
    default:                 return ''; // a newer engine may add a kind
  }
}
```

## Reconnecting and recovery

The SDK handles these by itself. Your page only shows the state.

| What happens | What the SDK does | State |
|---|---|---|
| Signalling drops (close code `1005` or `1006`), or the browser reports it is offline | Redials signalling on the same session and ticket. While the video path is still alive, the last picture stays on screen. The state stays `reconnecting` **until the renegotiated video actually plays**. If it does not play within 15 seconds of signalling reopening, the whole connection is rebuilt on the same session. | `reconnecting` → `streaming` |
| The video path dies while signalling is still up (the relay went away, a firewall dropped the flow). The browser reports the path failed, or disconnected for more than 6 seconds. | Rebuilds the connection on the same session. A shared-session viewer rejoins its room instead. | `reconnecting` → `connecting` → `streaming` (viewer: `recovering` → `connecting` → `streaming`) |
| A dial that does not open within 15 seconds | Dropped and dialled again. | `reconnecting` → `connecting` |
| The browser reports it is back online | The remaining wait is skipped. | |
| The reconnect window runs out | The session ends with code `4007`. | `ended`, `endKind: 'error'` |
| Signalling accepted the viewer and then sent no offer and no queue position for 210 seconds | The session ends with code `4104`. Not applied to a shared-session viewer, nor while queued. | `ended`, `endKind: 'error'` |
| The network allows neither a direct path nor the relay | The session ends with code `4100` about 8 seconds after the application's offer. A slow network gets up to 30 seconds before the verdict. | `ended`, `endKind: 'network-blocked'` |
| No video within 60 seconds of the application's offer: the video connection did not come up, or it came up and no first frame arrived | `stalled` fires and one fresh session is started (new session id and streamer id, a new ticket when the SDK requested the first one itself). If that fails too, the session ends with code `4101` (never connected) or `4102` (connected, no video). | `recovering`, then `ended`, `endKind: 'error'` |
| Connected, and no video frame for 10 seconds (not judged while the tab is hidden) | `stalled` fires and one fresh session is started. A second stall ends the session with code `4102`. | `recovering`, then `ended`, `endKind: 'error'` |

Redials wait about 1, 2, 4, 8 and then 15 seconds, each varied by ±20 % so that many viewers do not redial in the same second.

| Who | Reconnect window |
|---|---|
| A normal session, and the host of a shared session | 180 seconds |
| A viewer of a shared session | 10 minutes |

A normal session and a shared-session host reconnect only on a drop: any other close from the platform ends the session with the platform's code. A shared-session viewer keeps waiting on every close except the final ones (access refused, project switched off, no server available, application not found or failed, maximum runtime reached, no streamer connected, relay unavailable). Shared sessions do not start a fresh session after a stall: the host's session ends with `4101` or `4102`, and a viewer rejoins the room up to three times first.

A fresh session means a new application process: its state is lost and `launchParams` are sent again.

## Events

```ts
const off = stream.on('stats', (s) => console.log(s.fps, s.bitrateKbps));
off();                                            // unsubscribe

// @ts-expect-error  'stat' is not an event: a typo does not compile
stream.on('stat', () => {});

// An event added by an engine newer than your installed package (not in its types yet):
stream.onUnknown('someFutureEvent', (payload) => console.log(payload));
```

`on()` accepts only the event names below and returns the function that unsubscribes; `off(name, fn)` does the same by reference. `onUnknown(name, fn)` subscribes to any name. A listener that throws is logged and does not affect the stream or other listeners. **All listeners are removed when the session ends**, after `ended` has fired.

| Event | Payload | When |
|---|---|---|
| `state` | `StreamState` | Every state change. |
| `session` | `{ sessionId, streamerId }` | A platform session starts. Once per session; again with new ids when the SDK recovers into a fresh session; not on a reconnect that keeps the session. |
| `progress` | `{ stage: 'offer' \| 'answer' \| 'connected' }` | Loading steps: the application answered (a GPU is assigned), the browser's answer went back, the connection is up. |
| `queue` | `{ position, message? }` | The queue position changed. |
| `stats` | `StreamStats` | Every second while streaming. |
| `videoEncoderAvgQP` | `number` | The encoder's quantisation parameter, about once a second, on H.264's 0 to 51 scale whatever the codec. Lower is better quality. |
| `stalled` | `Diagnostics` | No video; recovery follows. `verdict` is a one-line explanation. |
| `relayFallback` | `{ transport: 'tcp' \| 'tls', showWarning }` | UDP is blocked on the viewer's network and the stream is relayed over TCP or TLS, at lower quality. `showWarning` is the project's "UDP blocked warning" setting. |
| `autoplayBlocked` | `{ reason }` | The browser refused to start playback. The state is `awaitingPlay`. |
| `afkWarning` | `{ kind: 'countdown', secondsRemaining, dismiss }` or `{ kind: 'dismissed' }` | The idle countdown started, counted down, or was cancelled. Call `dismiss()` or `stream.keepAlive()` when the viewer is still there. |
| `osk` | `{ contents }` | The application asked for the on-screen keyboard (a text field got focus). Show a text input and answer with `stream.sendTextboxEntry(text)`. |
| `oskHide` | | The application asked to hide the keyboard. |
| `ueMessage` | `unknown` | A message from your application, usually a JSON string. |
| `openUrl` | `{ url, open }` | The application sent a plain `https` link for the viewer. `open()` opens it in a new tab; on phones and tablets call it from a tap. |
| `fileProgress` | `{ received, total, name }` | A file from the application is arriving. |
| `file` | `{ blob, name, mimeType }` | A file from the application arrived. |
| `screenshot` | `{ dataUrl }` | The application asked for a screenshot (its `requestScreenshot` message). |
| `ended` | `{ code, reason, endKind, message }` | The session is over. |

### Without a listener

Three events have a built-in action that runs only when your page has no listener for them:

| Event | Without a listener |
|---|---|
| `openUrl` | Desktop browsers open the link in a new tab. Phones and tablets do nothing (they refuse a tab opened outside a tap): add a listener with a button. |
| `file` | Desktop browsers download the file. Phones and tablets do nothing: add a listener with a Save button. |
| `screenshot` | The frame is downloaded as `pixelstream_screenshot.png`. |

### Events that fire once

`session` and the first `connecting` fire one moment after `create()` resolves. Attach listeners directly after `await StreamPixel.create(...)`. If your code awaits something else first, read `stream.state`, `stream.currentSessionId` and `stream.currentStreamerId` instead.

```ts
stream.on('session', ({ sessionId, streamerId }) => {
  analytics.track('stream_session', { userId: currentUser.id, sessionId, streamerId });
});
```

These are the ids shown in your Streampixel analytics, so storing them links a session to your own user.

### `StreamStats`

| Field | Type | Meaning |
|---|---|---|
| `fps` | `number` | Frames decoded per second. |
| `latencyMs` | `number` | Network round-trip time. |
| `framesDecoded`, `framesDropped` | `number` | Totals for this connection. |
| `bitrateKbps` | `number \| null` | Received video bitrate. |
| `resolution` | `string \| null` | For example `"1920x1080"`. |
| `codec` | `string \| null` | For example `"H264"`. |
| `relayTransport` | `'' \| 'udp' \| 'tcp' \| 'tls'` | Transport of the relay in use; empty on a direct path. |
| `avgQp` | `number \| null` | Latest encoder quantisation parameter (0 to 51 scale). |
| `packetsLost` | `number` | Video packets lost since this connection started. |
| `bytesReceived` | `number` | Bytes received, video and audio, since this connection started. |

## Methods and properties

### Talking to your application

```ts
const sent: boolean = stream.send({ action: 'teleport', to: 'lobby' }); // false = not sent (nothing is queued)
const ran: boolean = stream.consoleCommand('stat fps');                 // false = not sent
stream.sendTextboxEntry('typed text');                                  // answers an `osk` event
```

| Call | Returns | Meaning |
|---|---|---|
| `send(payload)` | `boolean` | Sends an object or a string to the application (a Pixel Streaming UI interaction). `false` when it was not sent: before the video is up, while reconnecting, after the end. Nothing is queued: send it again once the state is `streaming`. |
| `consoleCommand(cmd)` | `boolean` | Sends a console command. `false` when it was not sent: as for `send()`, and when the application does not allow console commands (it must be launched with `-AllowPixelStreamingCommands`). |
| `sendTextboxEntry(text)` | | Answers an `osk` event. |

```ts
function sendWhenStreaming(payload: object) {
  if (stream.send(payload)) return;
  const off = stream.on('state', (s) => {
    if (s.kind === 'streaming' && stream.send(payload)) off();
  });
}
```

The SDK acts on some messages from the application (they still reach `ueMessage`): `{ "message": { "type": "heartbeat" } }` cancels a running idle countdown; `{ "type": "togglehoveringmouse", "value": true }` switches hover mouse; `requestScreenshot` and a plain `https://` link raise the events above.

### Video, sound and input

| Call | Returns | Meaning |
|---|---|---|
| `setResolution(width, height)` | `{ width, height } \| null` | Asks the application to render at this size, lowered to the maximum (keeping the aspect ratio) and rounded to even numbers. Returns what was sent, or `null` when nothing was sent (numbers under 64, no stream up, after the end, and always for a shared-session viewer: the size is the host's). A size asked for before the stream is up is remembered and applied when it starts, and after every reconnect. In `dynamic` and `crop` modes the size is the new upper limit and the stream is fitted to the container under it. Needs no console-command permission. |
| `allowedResolutions` | `string[]` | The project's sizes up to its maximum, for a picker: `"360p (640x360)"` … `"4K (3840x2160)"`. |
| `play()` | | Starts playback in the `awaitingPlay` state. Call it from a click or tap. |
| `muted` | `boolean` | Whether the sound is muted. Streams start muted: browsers require a user gesture before sound. |
| `setMuted(muted)` | `boolean` | Mutes or unmutes. Returns the muted state now in effect. |
| `toggleAudio()` | `boolean` | Flips mute. Returns `true` when the sound is now on. |
| `setMicrophone(on)` | `Promise<boolean>` | Turns the viewer's microphone on or off while the stream is up. Resolves to whether it is now live. The microphone must be allowed at the start (`media.mic`, or the dashboard); otherwise it resolves `false` and nothing is captured. The first call asks the browser for permission: call it from a click or tap. Always `false` for a shared-session viewer. |
| `setCamera(on)` | `Promise<boolean>` | The same for the camera (`media.camera`). |
| `setHoverMouse(enabled)` | | Hover mouse on or off. |
| `toggleXR()` | | Enters or leaves the WebXR session. |
| `keepAlive()` | | The viewer is still there: restarts the idle timer, and cancels the countdown when one is showing. |
| `captureScreenshot()` | `string \| null` | PNG data URL of the current frame; `null` before the first frame. |

Keys typed into your page's own `<input>`, `<textarea>`, `<select>` and editable elements are not sent to the application. When the tab is hidden or loses focus, held keys and mouse buttons are released in the application. On phones and tablets, a tab left in the background for 60 seconds ends the session.

### Session

| Member | Type | Meaning |
|---|---|---|
| `state` | `StreamState` | The current state. |
| `projectId` | `string` | The project id the platform resolved. |
| `streamerId`, `currentStreamerId` | `string` | The streamer id of the session that is up (the same value under two names). The host of a shared session gives it to viewers. Changes when the SDK recovers into a fresh session. |
| `currentSessionId` | `string` | The platform's session id. Changes when the SDK recovers into a fresh session. |
| `streamConfig` | object | The project's stream settings for this session, branding included (`customLogo`, `loadingBannerUrl`, `loadingTextOne` / `Two` / `Three`, `chatTheme`), for your own screens. Before a password is accepted it holds the branding only. |
| `voiceToken` | `string \| undefined` | Present when the project has chat on. |
| `engineVersion` | `string` | Version of the engine running this stream. |
| `engineSource` | `'cdn'` | How the engine was loaded. |
| `getDiagnostics()` | `Promise<DiagnosticsSnapshot \| null>` | A snapshot of the video connection (ICE states, candidates, relay in use, `verdict`, `likelyCause`), for support requests. `null` when there is no connection. The addresses in it are not masked. |
| `submitPassword(password)` | `Promise<void>` | Answers the `awaitingPassword` state. |
| `attach(element)` | | Moves the video into another element. In `dynamic` and `crop` modes the stream is then sized to that element. |
| `disconnect()` | | Ends the session and removes the video. Never reconnects. `ended` fires with code `1000` and `endKind: 'user'`. |
| `destroy()` | | `disconnect()` if the session is still live, and drops every listener. Safe to call more than once. Call it before creating another stream in the same container, and when your component unmounts. |
| `pixelStreaming` | `unknown` | Epic's `PixelStreaming` object for this connection, for code written against Epic's library. It is replaced when the SDK rebuilds the connection: read it each time you use it. Do not call its `reconnect()`, `unmuteMicrophone()` or `unmuteCamera()`: the SDK owns reconnection and capture. |

`ended` is final: there is no `connect()` or `reconnect()` on a stream. To start again, destroy it and create a new one:

```ts
import { StreamPixel } from '@streampixel/web-sdk';
import { mountUI, type MountedUI } from '@streampixel/ui';

const container = document.getElementById('stream')!;
let stream: StreamPixel | undefined;
let ui: MountedUI | undefined;

async function start() {
  ui?.destroy();       // the UI first, then the stream
  stream?.destroy();
  stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });
  ui = mountUI(stream, { container, onRestart: start }); // "Start again" on the ended card
}
start();
```

`destroy()` on a live stream fires `ended` (code `1000`, `endKind: 'user'`) before it drops the listeners. If you restart on `ended`, check `endKind`, or unsubscribe before you destroy.

### v1 and Epic names

These exist so that v1 code can move in steps. Prefer the names above.

| Call | Same as |
|---|---|
| `addEventListener(name, fn)`, `removeEventListener(name, fn)` | Epic's events by their original names (`webRtcConnected`, `playStream`, `afkWarningActivate`, …). The SDK attaches your listeners again when it rebuilds the connection. |
| `addResponseEventListener(name, fn)`, `removeResponseEventListener(name)` | `on('ueMessage', fn)`, with the message as a string. |
| `emitUIInteraction(data)` | `send(data)`; returns the same boolean. |
| `emitConsoleCommand(cmd)` | `consoleCommand(cmd)`; returns the same boolean. |

<a id="how-a-session-ends"></a>

## How a session ends, and end codes

```ts
const stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });
stream.on('ended', ({ code, reason, endKind, message }) => {
  showMessage(message);                         // for the viewer
  console.log({ code, reason, endKind });       // for you and for support
  if (code === DisconnectCodes.NETWORK_BLOCKED) showMessage('Ask your IT team to allow the stream, or try another network.');
});
```

| Field | Meaning |
|---|---|
| `code` | The end code (tables below). `DisconnectCodes` exports the names. |
| `reason` | The server's own text, or the SDK's description. For logs and support. |
| `endKind` | Who ended it (next table). |
| `message` | A sentence in plain language for the viewer, the same wording as Streampixel's share page. |

| `endKind` | When | Codes |
|---|---|---|
| `user` | Your code called `disconnect()` or `destroy()`, or aborted `signal`. | `1000` |
| `afk` | The idle time ran out, or a phone or tablet left the tab in the background for 60 seconds. | `1000` |
| `server` | The platform closed the session. | the platform's code |
| `error` | The SDK gave up. | `4007`, `4101`, `4102`, `4103`, `4104` |
| `network-blocked` | The viewer's network allows neither a direct path nor the relay. | `4100` |

### Codes sent by the platform

| Code | `DisconnectCodes` | `message` |
|---|---|---|
| `1000` | `CLEAN` | "The stream has ended." (`user`); an inactivity sentence (`afk`); "The stream was disconnected." (`server`) |
| `1001` | `GOING_AWAY` | "The stream was disconnected (…)." |
| `1008` | `UNAUTHORIZED` | "Access was refused: the stream ticket is invalid or has expired. Start a new session to continue." |
| `4000` | `PROJECT_INACTIVE` | "This stream has been turned off by the project owner." |
| `4001` | `NO_WORKER_AVAILABLE` | "No streaming server is available right now. Please try again in a few minutes." |
| `4002` | `APPLICATION_NOT_FOUND` | "The application could not be found on the streaming server. Please contact the project owner." |
| `4003` | `APPLICATION_ERROR` | "The application reported an error and could not continue. Please try again." |
| `4004` | `MAX_RUNTIME_REACHED` | "The session ended after reaching its maximum allowed runtime." |
| `4005` | `STREAMER_TIMEOUT` | "The application took too long to start. Please try again." |
| `4006` | `STREAMER_DISCONNECTED` | "The application closed unexpectedly. Start a new session to continue." |
| `4008` | `SESSION_SETUP_FAILED` | "The session could not be set up. Please try again." |
| `4009` | `SESSION_TERMINATED_BY_PLATFORM` | "The session has ended. Start a new one to continue." |
| `4010` | `RELAY_UNAVAILABLE` | "The secure relay for this stream is unavailable right now. Please try again in a few minutes." |
| `4401` | `ADMISSION_REQUIRED` | "The stream did not accept this session's access ticket. Start a new session to continue." |

`1005` and `1006` (`ABNORMAL`) are connection drops. They never end a session by themselves: the SDK reconnects, and ends with `4007` if that fails. `DisconnectCodes.SESSION_TERMINATED` is a deprecated second name for `4000`.

### Codes decided by the SDK in the browser

The platform never sends these. They mean the cause is on the viewer's side of the connection, or between the viewer and the platform, so there is nothing to look for in the platform's logs of the application.

| Code | `DisconnectCodes` | Meaning | `message` |
|---|---|---|---|
| `4007` | `RECONNECT_FAILED` | The connection dropped and could not be restored within the reconnect window. | "We could not reconnect to the stream." |
| `4100` | `NETWORK_BLOCKED` | The viewer's network allows neither a direct path nor the relay. | "This network blocks the connection the stream needs. Ask your IT team to allow it, or try another network." |
| `4101` | `MEDIA_CONNECT_FAILED` | Offer and answer were exchanged and the video connection never came up, also after one fresh session. | "The video connection could not be established. A firewall or VPN may be in the way: try another network, or try again." |
| `4102` | `NO_MEDIA` | Connected, and no video frames arrived, also after one fresh session. | "The stream stopped sending video. Please try again." |
| `4103` | `CLIENT_SETUP_FAILED` | The SDK could not build the connection from what the platform sent (no signalling host, an unusable relay list or offer). | "The stream could not be started in this browser. Please try again." |
| `4104` | `START_TIMEOUT` | Signalling accepted the viewer and then sent no offer and no queue position for 210 seconds. | "The stream did not start in time. Please try again." |

The SDK also ends with `4010` itself when the project forces the relay and the platform handed out none.

## Shared sessions

A shared session runs **one** application for several people. The **host** owns the session and the input. **Viewers** watch the same stream and cannot control it.

```ts
const host = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container, shared: { role: 'host' } });
sendToViewers(host.streamerId); // the id viewers need, exactly as read here
```

```ts
const viewer = await StreamPixel.create({
  appId: 'YOUR_PROJECT_ID',
  container,
  shared: { role: 'viewer', hostStreamerId }, // the host's stream.streamerId
});
```

The host's `stream.streamerId` is the id of the room. A viewer passes it unchanged as `hostStreamerId`. It has the form `<id>_<projectId>`.

| Topic | Behaviour |
|---|---|
| Host role | The SDK asks the platform for a ticket that names the host's room, and keeps the key the platform returns for it (this tab only, `sessionStorage`). Whoever opens a room first is its host. |
| Room already taken | `create()` rejects with `AuthError` kind `shared-room-taken`. |
| Host page reload | The host comes back to the **same room**: the room id is kept for the tab (`sessionStorage`, per project). The application keeps running and viewers keep watching. A new tab opens a new room. |
| Second `create()` in the same page | Opens a new room (React StrictMode's double effect in development included). To rejoin the previous room on purpose, pass its id: `advanced: { streamerId: previous.streamerId }`. |
| Storage blocked | A new room on every `create()`. |
| Viewers | Watch-only: mouse, keyboard, touch, gamepad, microphone and camera are off, whatever the options say. No idle timeout. They send nothing to the application (`isTouchDevice`, startup commands, `launchParams`) and cannot change the resolution: `setResolution()` returns `null`. |
| Host's application restarts | Viewers go to `reconnecting` with `waitingForHost: true` and wait up to 10 minutes. The platform may end a viewer sooner when no host comes back. |
| Viewer's video stops | The viewer rejoins the room, up to three times (`recovering`, `attempt` 1 to 3). |
| Host's video stops | The host's session ends (`4101` or `4102`). No fresh session is started: it would restart the application under every viewer. |

### Shared sessions with "your app only"

With `auth: { mode: 'ticket' }` the SDK requests nothing, so **your server must ask for the host role itself**. Add an `sfu` field to the body of the ticket request:

| Ticket for | `sfu` in the request body |
|---|---|
| The host, opening a room | `{ "role": "host", "roomId": "<room id>" }` |
| The host again, same room (after a page reload) | `{ "role": "host", "roomId": "<room id>", "hostKey": "<key>" }` |
| A viewer | `{ "role": "viewer" }` |

```ts
// YOUR SERVER: a ticket for the HOST of a shared session.
export async function requestHostTicket(projectId: string, viewerId: string, roomId: string, hostKey?: string): Promise<unknown> {
  const res = await fetch('https://platform.streampixel.io/api/v1/stream/ticket', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-server-key': process.env.STREAMPIXEL_SERVER_KEY ?? '' },
    body: JSON.stringify({
      projectId,
      viewerId,
      sfu: { role: 'host', roomId, ...(hostKey ? { hostKey } : {}) },
    }),
  });
  if (!res.ok) throw new Error(`Streampixel ticket request failed: ${res.status}`);
  // The answer carries sfu: { role: 'host', roomId, hostKey }. Keep hostKey on your server for this room:
  // the next host ticket for the same room (after the host's page reloads) must send it back.
  return res.json();
}
```

- The response carries `sfu: { role: 'host', roomId, hostKey }`. The SDK connects as that `roomId`, and `stream.streamerId` is that id: give it to viewers as `hostStreamerId`.
- Use the form the SDK uses for its own room ids: `<your room id>_<projectId>`, letters, digits, `_` and `-` only.
- Every participant needs a ticket of its own: the host, each viewer, and a new one for every `create()`.

## Voice, text and video chat

Chat is a separate entry point, `@streampixel/web-sdk/voice`, so pages without chat never download it. Like the stream engine, the chat code is downloaded from Streampixel's servers when first used, with the same checks. The project must have chat switched on in the dashboard; otherwise `stream.voiceToken` is `undefined` and `VoiceChat.for()` rejects.

```ts
const stream = await StreamPixel.create({ appId: 'YOUR_PROJECT_ID', container });

if (stream.voiceToken) {                       // undefined when the project has chat off
  const chat = await VoiceChat.for(stream, { userName: 'Alex' });
  chat.on('message', ({ from, text }) => addLine(from, text));
  chat.on('roster', ({ localParticipant, remoteParticipants }) => renderPeople(localParticipant, remoteParticipants));
  await chat.join();
  await chat.toggleMic(true);                  // the microphone starts off
}
```

| `VoiceChat.for(stream, options)` | Type | Default | Meaning |
|---|---|---|---|
| `userName` | `string` | required | Name shown to the others. |
| `avatar` | `string` | | Avatar URL shown to the others. |
| `voice` | `boolean` | `false` | Open the microphone on join. |
| `roomId` | `string` | | A room inside the project's room. Without it, everyone on the project is in one room. |
| `platformHost` | `string` | `https://platform.streampixel.io` | **Not taken from the stream**: if you set `advanced.platformHost` on the stream, pass the same host here. |
| `livekitUrl` | `string` | Streampixel's chat server | For deployments with their own chat server. |

| Call | Returns | Meaning |
|---|---|---|
| `join()`, `leave()` | `Promise<void>` | Enter or leave the room. The chat leaves by itself when the stream ends. |
| `toggleMic(enable)`, `toggleCamera(enable)` | `Promise<boolean>` | Whether the change took effect (`false` when permission was refused). |
| `sendMessage(text)` | | Sends a text message. Your own message comes back as a `message` event with `from: 'You'`. |
| `sendTyping()` | | Tells the others this viewer is typing. |
| `setRemoteAudio(enabled, id?)` | | Stop or resume hearing one participant, or everyone, for this viewer only. |
| `on(event, fn)` | unsubscribe function | Events: `message` `{ from, text, avatar? }`, `roster` `{ localParticipant, remoteParticipants }`, `typing` `{ from, avatar? }`, `deviceError` `{ name, kind?, message }`. |

Each participant in `roster` is `{ id, avatar?, speaking, micMuted, videoTrack }`; `videoTrack` is `null` when the camera is off.

Some applications put the viewer into chat themselves, with a `comms` message (`{ "message": { "type": "comms", "value": { "roomId": "…", "name": "…" } } }`, and `"value": "disconnect"` to leave). The SDK does not join by itself; listen for it:

```ts
let chat: Awaited<ReturnType<typeof VoiceChat.for>> | null = null;

stream.on('ueMessage', async (m) => {
  const msg = typeof m === 'string' && m.trim().startsWith('{') ? JSON.parse(m) : m;
  if (msg?.message?.type !== 'comms') return;
  const value = msg.message.value;
  if (value === 'disconnect') {
    await chat?.leave();
    chat = null;
  } else if (!chat) {
    chat = await VoiceChat.for(stream, { userName: value.name, roomId: value.roomId });
    await chat.join();
  }
});
```

## React

In development under `<StrictMode>`, React runs an effect, its cleanup, and the effect again when a component mounts. In production a fast route change unmounts a component just after it mounted. In both cases the cleanup runs before `create()` has resolved, so a cleanup that only calls `stream.destroy()` has no stream to destroy yet, and that `create()` then resolves into a session nobody holds: a GPU session streaming unseen.

Pass an `AbortSignal` and abort it in the cleanup. Aborting before `create()` resolves rejects it with `AbortError` and starts nothing. Aborting afterwards destroys the stream.

```tsx
import { useEffect, useRef, useState } from 'react';
import { StreamPixel, type StreamState } from '@streampixel/web-sdk';

export function useStreamPixel(appId: string) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [stream, setStream] = useState<StreamPixel | null>(null);
  const [state, setState] = useState<StreamState | null>(null);
  const [error, setError] = useState<unknown>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const ac = new AbortController();
    let off: (() => void) | undefined;
    setStream(null);
    setState(null);
    setError(null);

    StreamPixel.create({ appId, container, signal: ac.signal })
      .then((s) => {
        setStream(s);
        setState(s.state);            // 'awaitingPassword' already, on a password project
        off = s.on('state', setState);
      })
      .catch((err: unknown) => {
        if ((err as Error)?.name !== 'AbortError') setError(err);
      });

    return () => {
      off?.();     // destroy() announces 'ended' before it drops listeners: stop listening first
      ac.abort();  // before create() resolves: nothing starts. After: the stream is destroyed.
    };
  }, [appId]);

  return { containerRef, stream, state, error };
}

export function Stream({ appId }: { appId: string }) {
  const { containerRef, state, error } = useStreamPixel(appId);
  const text = error ? 'The stream could not start.'
    : !state ? 'Loading…'
    : state.kind === 'ended' ? state.message
    : state.kind === 'streaming' ? ''
    : state.kind;
  return (
    <div style={{ position: 'relative', width: '100%', aspectRatio: '16 / 9' }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
      {text && <p style={{ position: 'absolute', top: 8, left: 8 }}>{text}</p>}
    </div>
  );
}
```

Keep the container element empty in your JSX: the SDK adds and removes its own child there. The same pattern works in any framework with a cleanup step (Vue `onUnmounted`, Svelte `onDestroy`, Angular `ngOnDestroy`).

## Telemetry and privacy

The SDK reports to Streampixel's own telemetry service, with a token that is valid for that session only. These reports are what the session pages of your dashboard show.

| `telemetry` | Sent |
|---|---|
| `'standard'` (default) | Session lifecycle (start, every state change, reconnects, end, page unload), WebRTC diagnostics at the steps of the connection and at failures, and a statistics row about once a minute (frame rate, bitrate, resolution, codec, packet loss, bytes received). |
| `'minimal'` | Session lifecycle only. |

There is no "off" value. Nothing is sent before a ticket exists (a password project waiting for its password), nor when the ticket you pass in `auth: { mode: 'ticket' }` has no `telemetryToken`.

| Fact | Detail |
|---|---|
| Where | `POST https://telemetry.streampixel.io/api/frontend-streaming-logs` (or `advanced.telemetryHost`). Each request has a 1.5 second limit and never delays the stream. |
| With every row | Session id, streamer id, project id and region, operating system, browser, device class, the page's origin and path (never its query string or fragment), the viewer's approximate location as the platform reports it, the SDK version, and timestamps. |
| Addresses | The viewer's own network addresses in WebRTC diagnostics are shortened before they are sent (IPv4 to the first two numbers, IPv6 to the first two groups). `getDiagnostics()`, which returns to your page, is not shortened. |
| Never sent | Passwords, tickets, your `launchParams`, messages to or from your application. |
| Third parties | None. No analytics SDK, no tracker, no cookie. |

What the SDK stores in the browser:

| Storage | Key | What |
|---|---|---|
| `sessionStorage` | `spx:pw:<projectId>` | A correct project password, for this tab (`rememberPassword: false` turns it off). |
| `sessionStorage` | `spx:sfuHost:<projectId>`, `spx:sfuHostKey:<roomId>` | A shared-session host's room id and the key for it, for this tab. |
| `localStorage` | `spx.sdk.seq` | The number of the newest engine manifest seen, to refuse an older one. |

## What is not in this package

| Not here | Where it is, or what to do |
|---|---|
| The engine | Downloaded by `create()`. No fallback copy. |
| Any screen: loading, password, "Click to start", idle warning, text input for phones, end message, controls | `@streampixel/ui`, or your own code on the states and events. `loading: true` was removed. |
| Screens before a stream exists: project offline, not found, sign-in failed | Yours: `create()` rejects with an `AuthError`, which carries the project's `branding`. |
| A `connect()` / `reconnect()` / restart on the same object | `destroy()` and `create()` again. |
| Reading a project's access mode or branding without starting | Not available. |
| Encoder QP options (`minQP`, `maxQP`) | Set in the dashboard. |
| Epic's classes (`Config`, `Flags`, `PixelStreaming`, …) | Not exported. `stream.pixelStreaming` is the instance. |
| Messages posted to a parent window | None. The share page, when embedded as an iframe, posts `stream-metadata` to its parent; the SDK runs in your page, so use the `session`, `state` and `ended` events. |
| A React package | None. Use the hook in [React](#react). |
| Voice chat and `@streampixel/ui` in the script-tag build | npm only. |

## Browser requirements

- A browser with WebRTC (`RTCPeerConnection`). Without it `create()` rejects with `AuthError` kind `network`.
- A page served over `https` or from `localhost` (WebCrypto).
- The codec is negotiated against what the browser can decode: a browser without the preferred codec uses the fallback.
