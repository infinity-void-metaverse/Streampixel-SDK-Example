# @streampixel/core

Headless streaming engine for the [StreamPixel](https://streampixel.io) platform.
TypeScript, zero third-party trackers, no UI opinions — bring your own interface
or use `@streampixel/ui` / `@streampixel/react` (coming) on top.

```bash
npm install @streampixel/core
```

## Quick start

```ts
import { StreamPixel } from '@streampixel/core';

const stream = await StreamPixel.create({
  appId: 'YOUR_PROJECT_ID',
  container: document.getElementById('stream')!,
});

stream.on('state', (s) => console.log('state:', s.kind));
stream.on('ended', ({ code, reason, endKind }) => showGoodbye(reason));
```

`create()` resolves access, mints a session ticket, and starts connecting. It
throws `AuthError` (with a machine-readable `kind`) when access is the problem —
wrong password, project offline, SSO required — so your UI can respond precisely.

## Authentication

```ts
// Public project (default)
auth: { mode: 'auto' }

// Password-gated project — verified server-side at ticket mint
auth: { mode: 'password', password: userInput }

// SSO-gated project — the SDK drives the OIDC redirect automatically
// (redirects to your IdP, exchanges the single-use grant on return).
// Use redirect: 'manual' to get AuthError{ kind: 'sso-required', ssoStartUrl }
// and perform the navigation yourself (SPAs with routing).
auth: { mode: 'sso' }   // 'auto' also handles this when the project is SSO-gated

// Programmatic — YOUR backend mints the ticket with its API key
// (POST /api/v1/stream/ticket) and hands the response to the browser.
// The SDK never sees an API key; the short-lived ticket is the only
// client credential.
auth: { mode: 'ticket', ticket: mintResponseFromYourBackend }
```

## States

```
resolving → (queued ⇄) starting → connecting → streaming
                              ↘ stalled → recovering → streaming
any → reconnecting → streaming | ended(code, reason, endKind)
```

- **`queued`** — capacity queue; `position` included, `queue` events fire on movement.
- **`stalled` / `recovering`** — the app stopped producing frames; the SDK
  terminates and transparently retries once with a fresh session.
- **`reconnecting`** — network drop; automatic backoff retries for up to **180 s**.
- **`ended`** — final. `endKind` is `'user' | 'afk' | 'server' | 'error' | 'network-blocked'`,
  `code` uses the documented platform disconnect codes (`DisconnectCodes`).

Corporate-firewall detection is built in: if the network blocks UDP **and** TURN
relay, the session ends within ~8 s with `endKind: 'network-blocked'` and a
remediation message — no infinite spinners.

## Events

| Event | Payload | When |
|---|---|---|
| `state` | `StreamState` | every transition |
| `queue` | `{ position, message }` | queue position updates |
| `stats` | `StreamStats` (fps, latency, bitrate, codec, relayTransport) | 1 s cadence while streaming |
| `stalled` | `Diagnostics` | no-media watchdog fired |
| `afkWarning` | `{ kind: 'countdown', secondsRemaining, dismiss() }` \| `{ kind: 'dismissed' }` | idle countdown for your warning overlay |
| `osk` | `{ contents }` | UE requested text input (mobile keyboard) — reply with `sendTextboxEntry(text)` |
| `ended` | `{ code, reason, endKind }` | session over |
| `ueMessage` | `unknown` | messages from your Unreal application |

## Interacting with the application

```ts
stream.send({ action: 'teleport', to: 'lobby' });   // emitUIInteraction
stream.consoleCommand('stat fps');
stream.setResolution(2560, 1440);
stream.allowedResolutions;                           // the project's ladder, for pickers
stream.toggleAudio();                                // drives the lib's audio element
stream.sendTextboxEntry('typed text');               // answer an `osk` event
stream.setHoverMouse(true);
stream.toggleXR();
stream.captureScreenshot();                          // PNG data URL of current frame
const diag = await stream.getDiagnostics();          // full WebRTC snapshot
stream.disconnect();                                 // deliberate, never reconnects
```

## UI: headless by default, one opt-in nicety

Core paints nothing — build your own interface on the states and events, using
`stream.streamConfig` for the project's branding (logo, loading banner,
loading texts, chat theme). The exception is opt-in:

```ts
loading: true   // minimal built-in loading screen in `container` until first
                // frame: project banner + texts, queue position, reconnect status
```

Full overlays (the share.streampixel.io experience) ship separately in
`@streampixel/ui`. Voice/text chat ships as a lazy subpath
(`@streampixel/core/voice`) so LiveKit never lands in bundles that don't use
chat — the ticket mint already provides `stream.voiceToken` when the project
has chat enabled.

## Shared viewing (SFU)

One UE instance, many watchers. The host owns the session and input; viewers
are watch-only (enforced server-side, and input is disabled locally too):

```ts
// Host page
const host = await StreamPixel.create({ appId, container, shared: { role: 'host' } });
shareWithViewers(host.streamerId);   // however your app distributes the link

// Viewer pages
await StreamPixel.create({ appId, container, shared: { role: 'viewer', hostStreamerId } });
```

Omit `shared` for a normal private session.

## Options (all optional beyond `appId`)

```ts
codec:      { primary: 'AV1', fallback: 'H264' }     // dashboard config is the default
resolution: { start: '1080p (1920x1080)' }           // or { width, height }
bitrate:    { min: 1_000_000, max: 20_000_000 }
input:      { mouse, keyboard, touch, hover, gamepad, xr, fakeMouseWithTouches }
media:      { mic: false, camera: false }
afk:        { timeoutSec: 300 }
telemetry:  'standard' | 'minimal'                    // first-party only, never third-party
advanced:   { iceTransportPolicy: 'relay', platformHost, streamerId }
```

## Telemetry & privacy

The SDK reports session lifecycle and WebRTC quality to StreamPixel's own
telemetry pipeline, authenticated by a session-scoped token from the ticket
mint. `'minimal'` restricts this to lifecycle events. **There are no third-party
trackers, no cookies, and no analytics SDKs of any kind in this package.**
The build is unobfuscated with sourcemaps — audit it.

## Browser support

Evergreen Chrome / Edge / Firefox, Safari 16+. Codec preference is negotiated
against actual browser decode capabilities (AV1 → H264 fallback is automatic).
SSR-safe: importing the package touches no browser globals; only
`StreamPixel.create()` requires a browser.
